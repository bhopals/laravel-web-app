-   https://www.youtube.com/watch?v=074AQVmvvdg (DB Migration Beginner)
-   https://www.youtube.com/watch?v=1Zyr-xi4bPk (DB Migration Advance)

-   https://www.youtube.com/watch?v=iaXtpAYfiy4 (Eloquent Model)
