-   https://www.youtube.com/watch?v=074AQVmvvdg (DB Migration Beginner)
-   https://www.youtube.com/watch?v=1Zyr-xi4bPk (DB Migration Advance)

-   https://www.youtube.com/watch?v=iaXtpAYfiy4 (Eloquent Model)

-   https://www.youtube.com/watch?v=lPr9jD7qcdg (Auth)

LIST:

-   https://www.youtube.com/watch?v=38zvoDYiDNo&list=PL4cUxeGkcC9hL6aCFKyagrT1RCfVN4w2Q&index=27

S3 Bucket

-   https://www.youtube.com/watch?v=FmspC3e2LEU

OAUTH

-   https://www.youtube.com/watch?v=K7RfBgoeg48
-   https://www.youtube.com/watch?v=LE1TC4WS4CY
-   https://www.youtube.com/watch?v=j-gF5Qwowy4 (Best)
